# Flight Booking Facade Pattern Lab

Java implementation of both phases of **Decoupling Subsystems with the Facade Pattern**.

## Run

Requires JDK 11 or newer. In this directory:

```bash
javac *.java
java Main
```

## Files

- `SeatInventorySystem.java`, `BaggagePricingEngine.java`, `CurrencyConverter.java`, `PaymentProcessor.java`, `TicketIssuer.java`: five provided subsystem implementations, kept unchanged in behavior.
- `FlightBookingFacade.java`: facade that manages seat locks, pricing, currency conversion, payment, ticket issuance, cleanup, and loyalty rules.
- `Main.java`: four required demonstration scenarios; references only the facade.
- `test-output.txt`: captured output from running the program.

## Required behavior

1. Standard booking succeeds and issues an e-ticket.
2. Blocked row 13 seat fails without terminating the program.
3. Invalid payment card releases the previously locked seat before disconnecting.
4. SILVER tier with 3 bags and 30 kg skips the baggage engine and receives the `SILVER-FREE-BAG` 10% discount.

The original 8-argument method delegates to the 9-argument overload with `STANDARD` loyalty. `GOLD` also skips baggage fees, without the SILVER-only promo.

## Architecture

`Main -> FlightBookingFacade -> five independent subsystems`

The facade owns the orchestration and error handling, so the client does not depend on subsystem details.
